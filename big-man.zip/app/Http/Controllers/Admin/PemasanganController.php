<?php

namespace App\Http\Controllers\Admin;

use Carbon\Carbon;
use App\Models\Paket;
use App\Models\Wilayah;
use App\Models\Pemasangan;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;

class PemasanganController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->addBreadcrumb('pemasangan', route('pemasangan.index'));
        $wilayahs = Wilayah::all();
        $date = date('Y-m-d');
        $pakets = Paket::all();
        $pemasangan = Pemasangan::with('pelanggan', 'pekerjaan', 'paket')->first();

        $pemasangan->route_id = $pemasangan->getRouteKey();
        $pemasangan->status = $pemasangan->getStatus();
        $pemasangan->created_atFormat = Carbon::parse($pemasangan->created_at)->format('H:i');

        return view('pages.admin.pemasangan', compact('wilayahs', 'date', 'pakets', 'pemasangan'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->addBreadcrumb('pemasangan', route('pemasangan.index'));
        $this->addBreadcrumb('tambah pemasangan baru', route('pemasangan.create'));
        $pakets = Paket::all();
        $wilayahs = Wilayah::all();
        return view('pages.pemasangan-create', compact('pakets', 'wilayahs'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($route_id)
    {
        $id = Crypt::decrypt($route_id);
        $detail = Pemasangan::with(['pelanggan', 'pekerjaan'])->findOrFail($id);
        $this->addBreadcrumb('pemasangan', route('pemasangan.index'));
        $this->addBreadcrumb('pemasangan user ' . $detail->pelanggan->nama, null);

        $pakets = Paket::all();
        $wilayahs = Wilayah::all();
        return view('pages.pemasangan-show', compact('detail', 'pakets', 'wilayahs'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
