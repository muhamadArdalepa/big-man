<?php

namespace App\Http\Controllers;

use App\Models\Tim;
use App\Models\User;
use App\Models\Absen;
use App\Models\Paket;
use App\Models\Laporan;
use App\Models\Wilayah;
use App\Models\Aktivitas;
use App\Models\Pekerjaan;
use App\Models\Pemasangan;
use App\Models\TimAnggota;
use App\Models\JenisGangguan;
use App\Models\JenisPekerjaan;
use App\Models\Other;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Crypt;

class PageController extends Controller
{
    public function __construct()
    {
        Carbon::setLocale('id');
    }
    public function home()
    {
        switch (auth()->user()->role) {
            case 1:
                $wilayah_id = auth()->user()->wilayah_id;

                $data['pekerjaan'] = Pekerjaan::queryPekerjaanWithWilayah($wilayah_id)->limit(2)->get();

                $data['pemasangan'] = Pemasangan::join('users', 'pelanggan_id', '=', 'users.id')
                    ->where([
                        'status' => 1,
                        'wilayah_id' => $wilayah_id
                    ])->whereMonth('pemasangans.created_at', date('m'));

                $data['permintaan'] = Pemasangan::join('users', 'pelanggan_id', '=', 'users.id')
                    ->where([
                        'status' => 'menunggu konfirmasi',

                        'wilayah_id' => $wilayah_id
                    ])->whereMonth('pemasangans.created_at', date('m'))->limit(3)->get();


                $data['nLaporan'] = Laporan::join('users', 'pelanggan_id', '=', 'users.id')
                    ->where([
                        'status' => 'aktif',
                    ])->whereMonth('laporans.created_at', date('m'));

                $data['laporans'] = Laporan::join('users', 'pelanggan_id', '=', 'users.id')
                    ->where([
                        'status' => 'menunggu konfirmasi',
                        'wilayah_id' => $wilayah_id
                    ])->whereMonth('laporans.created_at', date('m'))->limit(3)->get();


                $data['absen'] = Absen::join('users', 'user_id', '=', 'users.id')
                    ->with('users')
                    ->where('wilayah_id', $wilayah_id)
                    ->whereDate('absens.created_at', date('Y-m-d'));

                $data['teknisi'] = User::where(['role' => 2, 'wilayah_id' => $wilayah_id])->orderBy('poin', 'desc');

                $p = Pemasangan::selectRaw('DAY(pemasangans.created_at) as tanggal, COUNT(*) as jumlah')
                    ->join('users', 'pelanggan_id', '=', 'users.id')
                    ->where([
                        'status' => 'aktif',
                        'wilayah_id' => $wilayah_id
                    ])
                    ->whereMonth('pemasangans.created_at', date('m'))
                    ->groupBy('tanggal');

                $l = Laporan::selectRaw('DAY(laporans.created_at) as tanggal, COUNT(*) as jumlah')
                    ->join('users', 'pelanggan_id', '=', 'users.id')
                    ->where([
                        'wilayah_id' => $wilayah_id
                    ])
                    ->whereMonth('laporans.created_at', date('m'))
                    ->orderBy('tanggal')
                    ->groupBy('tanggal');

                $chart = [
                    $p->pluck('tanggal'),
                    $p->pluck('jumlah'),
                    $l->pluck('tanggal'),
                    $l->pluck('jumlah'),
                ];

                $aktivitas = Aktivitas::join('users', 'user_id', '=', 'users.id')
                    ->where(['wilayah_id' => $wilayah_id])
                    ->orderBy('aktivitas.created_at', 'asc')->get();
                return view('pages.admin.dashboard', compact('data', 'chart', 'aktivitas'));
                break;
            case 2:
                return view('pages.teknisi.dashboard');
                break;
            case 3:
                return view('pages.pelanggan.dashboard');
        }
    }
    public function pekerjaan()
    {
        $this->addBreadcrumb('pekerjaan', route('pekerjaan'));

        $wilayahs = Wilayah::all();
        $pakets = Paket::all();
        $jenis_gangguans = JenisGangguan::all();
        $date = date('Y-m-d');
        switch (auth()->user()->role) {
            case 1:
                return view('pages.admin.pekerjaan', compact('wilayahs',  'jenis_gangguans', 'pakets', 'date'));
                break;
            case 2:
                $pekerjaan = Pekerjaan::select(
                    'pekerjaans.*'
                )
                    ->join('tims', 'pekerjaans.tim_id', '=', 'tims.id')
                    ->join('tim_anggotas', 'tims.id', '=', 'tim_anggotas.tim_id')
                    ->where('tim_anggotas.user_id', auth()->user()->id)
                    ->where('tim_anggotas.user_id', auth()->user()->id)
                    ->latest()->first();
                $pekerjaan->route_id = $pekerjaan->getRouteKey();
                if ($pekerjaan->pemasangan_id) {
                    $pemasangan = Pemasangan::select('users.nama', 'alamat')->join('users', 'pelanggan_id', '=', 'users.id')
                        ->find($pekerjaan->pemasangan_id);
                    $pekerjaan->detail = $pemasangan->nama . ' - ' . $pemasangan->alamat;
                    $pekerjaan->nama_pekerjaan = 'Pemasangan';
                }
                if ($pekerjaan->laporan_id) {
                    $laporan = Laporan::select('users.nama', 'pemasangans.alamat')->join('users', 'pelanggan_id', '=', 'users.id')
                        ->join('pemasangans', 'user_id', '=', 'pemasangans.user_id')->find($pekerjaan->laporan_id);
                    $pekerjaan->detail = $laporan->nama . ' - ' . $laporan->alamat;
                    $pekerjaan->nama_pekerjaan = 'Perbaikan';
                }
                if ($pekerjaan->other_id) {
                    $other = Other::find($pekerjaan->other_id);
                    $pekerjaan->detail = $other->detail . ' - ' . $other->alamat;
                    $pekerjaan->nama_pekerjaan = $other->nama_pekerjaan;
                }

                $pekerjaan->created_atFormat = Carbon::parse($pekerjaan->created_at)->translatedFormat('H:i');
                $pekerjaan->updated_atFormat = Carbon::parse($pekerjaan->updated_at)->translatedFormat('H:i');
                return view('pages.teknisi.pekerjaan', compact('pekerjaan'));
                break;
        }
    }

    public function pekerjaan_show($route_id)
    {
        try {
            $id = Crypt::decrypt($route_id);
        } catch (\Throwable $th) {
            abort(404);
        }
        $this->addBreadcrumb('Pekerjaan', route('pekerjaan'));
        $this->addBreadcrumb('Pekerjaan ' . $id, route('pekerjaan.show', $id));
        $pekerjaan = Pekerjaan::findOrFail($id);
        switch ($pekerjaan->jenis_pekerjaan_id) {
            case 1:
                $detail = Pemasangan::select(
                    'pemasangans.*',
                    'users.nama',
                    'users.no_telp',
                    'users.email',
                    'users.foto_profil',
                    'marketer.nama as marketer'
                )
                    ->leftJoin('users', 'pelanggan', '=', 'users.id')
                    ->leftJoin('users as marketer', 'marketer', '=', 'marketer.id')
                    ->findOrFail($pekerjaan->pemasangan_id);
                break;
            case 2:
                $detail = Laporan::select(
                    'laporans.*',
                    'users.nama',
                    'users.no_telp',
                    'users.email',
                    'users.foto_profil',
                    'penerima.nama as penerima'
                )
                    ->leftJoin('users', 'pelapor', '=', 'users.id')
                    ->leftJoin('users as penerima', 'penerima', '=', 'penerima.id')
                    ->findOrFail($pekerjaan->laporan_id);
                break;
            default:
                $detail = $pekerjaan->detail;
                break;
        }
        // dd($detail);
        return view('pages.pekerjaan-show', compact('pekerjaan', 'detail'));
    }
    public function pemasangan()
    {
        switch (auth()->user()->role) {
            case 1:
                $this->addBreadcrumb('pemasangan', route('pemasangan.index'));
                $wilayahs = Wilayah::all();
                $date = date('Y-m-d');
                $pakets = Paket::all();
                $pemasangan = Pemasangan::with('pelanggan', 'pekerjaan', 'paket')->first();

                $pemasangan->route_id = $pemasangan->getRouteKey();
                $pemasangan->status = $pemasangan->getStatus();
                $pemasangan->created_atFormat = Carbon::parse($pemasangan->created_at)->format('H:i');

                return view('pages.admin.pemasangan', compact('wilayahs', 'date', 'pakets', 'pemasangan'));

            case 3:
                $pemasangan = Pemasangan::where('pelanggan_id', auth()->user()->id)->first();
                $this->addBreadcrumb($pemasangan ? 'Daftar Jaringan' : 'Detail Pemasangan', route('pemasangan'));
                if ($pemasangan) {
                    if ($pemasangan->status == 1) {
                        $detail = Pemasangan::with('pekerjaan', 'user')->where('pelanggan', auth()->user()->id)->first();
                        return view('pages.pemasangan-show', compact('detail'));
                    } else {
                        $detail = Pemasangan::with('pekerjaan', 'user')->where('pelanggan', auth()->user()->id)->first();
                        $pekerjaan = Pekerjaan::with('jenis_pekerjaan')->where('pemasangan_id', $pemasangan->id)->first();
                        return view('pages.pekerjaan-show', compact('pekerjaan', 'detail'));
                    }
                }
                $pakets = Paket::all();
                return view('pages.pelanggan.pemasangan-form', compact('pemasangan', 'pakets'));
            default:
                abort(404);
        }
    }

    public function pemasangan_show($id)
    {
        $this->addBreadcrumb('pemasangan', route('pemasangan'));
        $this->addBreadcrumb('pemasangan ' . $id, route('pemasangan.show', $id));
        $pemasangan = Pemasangan::with('user', 'marketer', 'paket')->find($id);
        $pakets = Paket::all();
        return view('pages.pelanggan.pemasangan-form', compact('pemasangan', 'pakets'));
    }
    public function laporan()
    {
        $jenis_gangguans = JenisGangguan::select('id', 'nama_gangguan')->get();
        $this->addBreadcrumb('laporan', route('laporan'));
        switch (auth()->user()->role) {
            case 1:
                $wilayahs = Wilayah::all();
                $date = date('Y-m-d');
                return view('pages.admin.laporan', compact('wilayahs', 'date', 'jenis_gangguans'));
                break;
            case 3:
                return view('pages.pelanggan.laporan', compact('jenis_gangguans'));
                break;
        }
    }

    public function laporan_show($id)
    {
        $this->addBreadcrumb('Laporan', route('laporan'));
        $this->addBreadcrumb('Laporan ' . $id, route('laporan.show', $id));

        return view('pages.admin.laporan_show');
    }
    public function tim()
    {
        $this->addBreadcrumb('tim', route('tim'));
        switch (auth()->user()->role) {
            case 1:
                $date = date('Y-m-d');
                $wilayahs = Wilayah::all();
                return view('pages.admin.tim', compact('wilayahs', 'date'));
                break;
            case 2:
                return view('pages.teknisi.tim');
                break;

            default:
                break;
        }
    }



    public function absen()
    {
        $this->addBreadcrumb('absen', route('absen'));

        $wilayahs = Wilayah::all();
        $date = date('Y-m-d');
        $id = auth()->user()->id;

        if (auth()->user()->role === 1) {
            return view('pages.admin.absen', compact('wilayahs', 'date'));
        }
        if (auth()->user()->role === 2) {
            $absen = Absen::select('created_at')
                ->where('user_id', $id)
                ->whereDate('created_at', date('Y-m-d'))
                ->orderBy('created_at', 'desc')
                ->first();
            $date = Carbon::parse($date)->translatedFormat("l, d F Y");
            $action = false;
            $whichAbsen = null;
            $hour = substr(now(), 11, 2);

            if ($absen == null) {
                if (($hour >= 8 && $hour < 9)) {
                    $action = true;
                    $whichAbsen = 'Pertama';
                }
            } else {
                $lastAbsen = substr(Carbon::parse($absen->created_at)->format('H:i:s'), 0, 2);
                if (($hour >= 11 && $hour < 12) && ($lastAbsen >= 8 && $lastAbsen < 11)) {
                    $whichAbsen = 'Kedua';
                    $action = true;
                }
                if (($hour >= 13 && $hour < 16) && ($lastAbsen >= 11 && $lastAbsen < 13)) {
                    $whichAbsen = 'Ketiga';
                    $action = true;
                }
                if (($hour >= 16) && ($lastAbsen >= 11 && $lastAbsen < 13)) {
                    $whichAbsen = 'Keempat';
                    $action = true;
                }
            }

            return view('pages.teknisi.absen', compact('date', 'action', 'whichAbsen'));
        }
    }


    public function teknisi()
    {
        $this->addBreadcrumb('teknisi', route('teknisi'));
        $wilayahs = Wilayah::all();
        return view('pages.admin.teknisi', compact('wilayahs'));
    }

    public function teknisi_show($id)
    {
        if (auth()->user()->role != 3) {
            $user = User::with('wilayah')->findOrFail($id);
            $tims = Tim::select('tims.id', 'user_id', 'users.nama as ketua', 'foto_profil', 'status')->join('users', 'user_id', '=', 'users.id')->get();
            foreach ($tims as $i => $tim) {
                $tim->anggota = TimAnggota::select('user_id', 'nama', 'foto_profil')->join('users', 'user_id', '=', 'users.id')->where('tim_id', $tim->id)->get();
            }
            $data = [];
            foreach ($tims as $i => $tim) {
                $isHasId = false;
                foreach ($tim->anggota as $anggota) {
                    if ($anggota->user_id == auth()->user()->id) {
                        $isHasId = true;
                    }
                }
                if ($tim->user_id == auth()->user()->id || $isHasId) {
                    $data[$i] = $tim;
                }
            }
            $this->addBreadcrumb('teknisi', route('teknisi'));
            $this->addBreadcrumb('profile', route('teknisi.show', $id));
            return view('pages.user-profile', with(['user' => $user, 'tims' => $data]));
        }
    }
    public function pelanggan()
    {
        $this->addBreadcrumb('pelanggan', route('pelanggan'));
        $wilayahs = Wilayah::all();
        return view('pages.admin.pelanggan', compact('wilayahs'));
    }

    public function wilayah()
    {
        $this->addBreadcrumb('wilayah', route('wilayah'));
        return view('pages.admin.wilayah');
    }
    public function paket()
    {
        $this->addBreadcrumb('paket', route('paket'));
        return view('pages.admin.paket');
    }

    public function auth_profile()
    {
    }
}
