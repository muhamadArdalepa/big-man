<h1>Selamat datang di Big Net</h1>
<p>Tinggal satu langkah lagi untuk dapat mengaktifkan akun kamu <a href="{{route('verify-email',['token'=>$token])}}">Konfirmasi email</a></p>