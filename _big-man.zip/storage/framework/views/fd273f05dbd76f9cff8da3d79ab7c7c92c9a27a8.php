<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\_big-man\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>