<!DOCTYPE html>
<html>
<head>
    <title>Get User Location with OpenStreetMap Nominatim API</title>
</head>
<body>
    <button onclick="getLocation()">Get My Location</button>
    <p id="location"></p>

    <script>
        function getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(getAddressFromCoordinates, showError);
            } else {
                document.getElementById('location').textContent = 'Geolocation is not supported by this browser.';
            }
        }

        function getAddressFromCoordinates(position) {
            var latitude = position.coords.latitude;
            var longitude = position.coords.longitude;

            // Buat permintaan ke API Nominatim
            fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`)
                .then(response => response.json())
                .then(data => {
                    var address = data.display_name;
                    document.getElementById('location').textContent = address;
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('location').textContent = 'Failed to get address.';
                });
        }

        function showError(error) {
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    document.getElementById('location').textContent = 'User denied the request for Geolocation.';
                    break;
                case error.POSITION_UNAVAILABLE:
                    document.getElementById('location').textContent = 'Location information is unavailable.';
                    break;
                case error.TIMEOUT:
                    document.getElementById('location').textContent = 'The request to get user location timed out.';
                    break;
                case error.UNKNOWN_ERROR:
                    document.getElementById('location').textContent = 'An unknown error occurred.';
                    break;
            }
        }
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\_big-man\resources\views/pages/test.blade.php ENDPATH**/ ?>