<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbars.auth.topnav', ['title' => 'Kelola Tim'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid py-4">
	<div class="row">
		<div class="col-12">
			<div class="card mb-4">
				<div class="card-body  d-flex align-items-center justify-content-between">
					<h6 class="m-0">Kelola Tim</h6>
					<button class="btn btn-danger m-0" data-bs-toggle="modal" data-bs-target="#tambahTimModal">
						<i class="fas fa-plus me-3"></i>
						Tambah Tim
					</button>
				</div>
			</div>
		</div>
	</div>
	<div class="row mt-3">
		<?php $__currentLoopData = $tims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-md-4 ">
			<div class="card ">
				<div class="card-header d-flex align-items-center justify-content-between">
					<h6 class="p-0 m-0">TIM<?php echo e($tim->id); ?></h6>
					<span class="badge bg-gradient-danger text-xxs">Status</span>
				</div>
				<hr class="horizontal dark mt-0">
				<div class="card-body pt-0">
					<p class="text-xxs font-weight-bolder opacity-7 mb-2">KETUA</p>
					<div class="d-flex align-items-center gap-3">
						<img src="/img/team-3.jpg" class="avatar" alt="user2">
						<p class="m-0"><?php echo e($tim->user->nama); ?></p>
					</div>
					<p class="text-xxs font-weight-bolder opacity-7 mt-3 mb-2">ANGGOTA</p>
					<?php $__currentLoopData = $anggotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($anggota->tim_id == $tim->id): ?>
					<?php if($anggota->user_id != $tim->user_id): ?>
					<div class="d-flex align-items-center gap-3 <?php echo e(!$loop->last ? 'mb-2' : ''); ?> ">
						<img src="/img/team-3.jpg" class="avatar" alt="user2">
						<p class="m-0"><?php echo e($anggota->user->nama); ?></p>
					</div>
					<?php endif; ?>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

	<?php echo $__env->make('layouts.footers.auth.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="modal fade" id="tambahTimModal" tabindex="-1" role="dialog" aria-labelledby="tambahTimModalLabel"
	aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="tambahTimModalLabel">Tambah Tim</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<h6 class="ps-2 mb-1 text-secondary text-xxs">KETUA</h6>
				<div class="card mb-3">
					<div class="card-body p-2 d-flex align-items-stretch justify-content-between">
						<div class="d-flex align-items-center gap-3">
							<img src="/img/team-3.jpg" class="avatar avatar-sm" alt="user2">
							<p class="m-0">Kamisato Ayaka</p>
						</div>
						<button class="btn btn-primary btn-sm px-3 m-0">
							<i class="fa-solid fa-delete-left"></i>
						</button>
					</div>

					<!-- <div class="card-body p-2 d-flex align-items-stretch justify-content-between">
						<div class="d-flex align-items-center gap-3">
							<img src="/img/team-3.jpg" class="avatar avatar-sm" alt="user2">
							<p class="m-0">Kamisato Ayaka</p>
						</div>
						<button class="btn btn-primary btn-sm px-3 m-0">
							<i class="fa-solid fa-delete-left"></i>
						</button>
					</div> -->
				</div>
				<div class="ms-md-auto pe-md-3 d-flex align-items-center">
					<div class="input-group w-100">
						<span class="input-group-text text-body"><i class="fas fa-search" aria-hidden="true"></i></span>
						<input type="text" class="form-control" placeholder="Cari Teknisi" onfocus="focused(this)"
							onfocusout="defocused(this)">
					</div>
				</div>
				<div id="hasil">
					<div class="input-group w-100">
						<span class="input-group-text text-body"><i class="fas fa-search" aria-hidden="true"></i></span>
						<input type="text" class="form-control" placeholder="Cari Teknisi" onfocus="focused(this)"
							onfocusout="defocused(this)">
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Batal</button>
				<button type="button" class="btn bg-gradient-primary">Simpan</button>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\big-man\resources\views/pages/kelola-tim.blade.php ENDPATH**/ ?>