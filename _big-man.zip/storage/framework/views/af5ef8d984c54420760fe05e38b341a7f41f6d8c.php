<nav aria-label="breadcrumb">
    <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
        <li class="breadcrumb-item text-sm"><a class="opacity-5 text-white" href="<?php echo e(route('home')); ?>"><i class="fa-solid fa-house"></i></a></li>
        <?php if(request()->route()->getname() != 'home'): ?>
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$loop->last): ?>
        <li class="breadcrumb-item text-sm text-white"><a class="opacity-5 text-white"
                href="<?php echo e($breadcrumb['url']); ?>"><?php echo e($breadcrumb['label']); ?></a></li>
        <?php else: ?>
        <li class="breadcrumb-item text-sm text-white active" aria-current="page"><?php echo e($breadcrumb['label']); ?></li>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ol>
    <h6 class="font-weight-bolder text-white mb-0"><?php echo e($title); ?></h6>
</nav><?php /**PATH C:\laragon\www\_big-man\resources\views/components/breadcrumbs.blade.php ENDPATH**/ ?>