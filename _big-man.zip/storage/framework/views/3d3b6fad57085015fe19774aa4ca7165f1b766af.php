<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/DataTables/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/plugins/Buttons/buttons.bootstrap5.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/custom-dataTables.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/plugins/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/DataTables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/DataTables/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/Buttons/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/Buttons/buttons.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/Buttons/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/Buttons/buttons.print.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\_big-man\resources\views/components/dataTables.blade.php ENDPATH**/ ?>