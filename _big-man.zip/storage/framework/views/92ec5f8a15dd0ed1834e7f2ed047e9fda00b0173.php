<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.navbars.guest.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="main-content">
        <div class="page-header align-items-start min-vh-50 py-5 m-3 border-radius-lg "
            style="background-image: url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/argon-dashboard-pro/assets/img/signup-cover.jpg'); background-position: top;">
            <span class="mask bg-gradient-dark opacity-6"></span>
            <div class="container pt-5">
                <div class="d-flex">
                    <div class="col-auto mx-auto">
                        <div class="card z-index-0">
                            <div class="card-body">
                                <p>Email verifikasi telah dikirimkan ke <strong><?php echo e(session('registered_email')); ?> </strong> </p>
                                <div class="small">Belum menerima kode? <a class="text-primary" href="<?php echo e(route('verify')); ?>">Kirim ulang kode</a></div>
                            </div>
                        </div>
                    </div>
            </div>
            </div>
        </div>
        
        
    </main>
    <?php echo $__env->make('layouts.footers.guest.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    document.getElementById('wilayah_id').addEventListener('click',function (e) {
        e.target.style.color = '#495057'
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\_big-man\resources\views/auth/verify-proses.blade.php ENDPATH**/ ?>